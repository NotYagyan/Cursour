const { GuildConfig } = require('../utils/database');
module.exports = GuildConfig; 
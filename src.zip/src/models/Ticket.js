const { Ticket } = require('../utils/database');
module.exports = Ticket; 